/* This class implements FlyingBehavior interface for those ducks who fly with wings*/
package com.example.demo;

public class FlywithWings implements FlyingBehavior{
	public FlywithWings()
	{
		
	}
	public String fly()
	{
		return "I am Flying";
	}

}
