/* Class for ducks who squeaks. This class implements quack behavior interface*/
package com.example.demo;


public class Squeak implements QuackBehavior{
	public Squeak()
	{
		
	}
	public String quack()
	{
		return "squeak";
	}

}
