/* This class implements QuackBehavior interface for those ducks who quack with rythm */
package com.example.demo;

public class QuackwithRythm implements QuackBehavior{
	public QuackwithRythm()
	{
		
	}
	public String quack()
	{
		return "Quacking with rythm";
	}

}
