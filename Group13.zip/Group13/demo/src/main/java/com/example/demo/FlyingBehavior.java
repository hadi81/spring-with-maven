/* Since different ducks have different flying behvior. So FlyingBehavior interface is created to
encapsulate them*/
package com.example.demo;

public interface FlyingBehavior {
	public String fly();

}
