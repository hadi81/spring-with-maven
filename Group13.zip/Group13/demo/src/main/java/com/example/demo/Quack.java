/* This class implements QuackBehavior interface for those ducks who can quack */

package com.example.demo;

public class Quack implements QuackBehavior{
	public Quack()
	{
		
	}
	public String quack()
	{
		return "Quack";
	}

}
