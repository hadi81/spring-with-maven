/* This class implements FlyingBehavior interface for those ducks who fly with rocket powered*/
package com.example.demo;

public class FlyRocketPowered implements FlyingBehavior {
	public FlyRocketPowered()
	{
		
	}
	public String fly()
	{
		return "I am flying with a rocket";
	}
	
}
