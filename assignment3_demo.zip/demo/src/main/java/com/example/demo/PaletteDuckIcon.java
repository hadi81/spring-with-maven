package com.example.demo;

import javax.swing.ImageIcon;
//import PaletteComponent;

public class PaletteDuckIcon extends PaletteComponent

{
    ImageIcon icon;

    public PaletteDuckIcon (ImageIcon icon)
    {
        this.icon = icon;
    }
}
