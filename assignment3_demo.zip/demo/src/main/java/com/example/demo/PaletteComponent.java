package com.example.demo;

public abstract class PaletteComponent 
{
    public void add (PaletteComponent paletteComponent)
    {
        throw new UnsupportedOperationException();
    }

    public void remove (PaletteComponent paletteComponent)
    {
        throw new UnsupportedOperationException();
    }

    public PaletteComponent getChild (PaletteComponent paletteComponent)
    {
        throw new UnsupportedOperationException();
    }

}