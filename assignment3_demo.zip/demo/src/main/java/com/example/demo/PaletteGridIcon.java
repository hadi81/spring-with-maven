package com.example.demo;

import javax.swing.ImageIcon;
import javax.swing.JPanel;
import java.util.ArrayList;

//import PaletteComponent;


public class PaletteGridIcon extends PaletteComponent

{
    ImageIcon icon;
    ArrayList gridComponents = new ArrayList();
    JPanel pannel = new JPanel();
    
    //pannel.add(pannelLabel);

    public PaletteGridIcon (ImageIcon icon)
    {
        this.icon = icon;
    }

    @Override
    public void add (PaletteComponent paletteComponent)
    {
        gridComponents.add(paletteComponent);
        //pannel.add(paletteComponent.icon);
    }

    @Override
    public void remove (PaletteComponent paletteComponent)
    {
        gridComponents.remove(paletteComponent);
        //pannel.remove(paletteComponent.icon);
    }

    public PaletteComponent getChild(int i)
    {
        return (PaletteComponent)gridComponents.get(i);
    }
}
