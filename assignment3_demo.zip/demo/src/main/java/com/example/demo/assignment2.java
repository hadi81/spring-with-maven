package com.example.demo;

import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.builder.SpringApplicationBuilder;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComponent;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.TransferHandler;
import java.awt.EventQueue;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.JOptionPane;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseMotionAdapter;
import java.awt.dnd.DnDConstants;
import java.awt.dnd.DragGestureEvent;
import java.awt.dnd.DragGestureListener;
import java.awt.dnd.DragSource;
import java.awt.dnd.DropTarget;
import java.awt.dnd.DropTargetAdapter;
import java.awt.dnd.DropTargetDropEvent;
import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Point;
import java.awt.datatransfer.DataFlavor;
import java.awt.datatransfer.Transferable;
import java.awt.datatransfer.UnsupportedFlavorException;
import java.io.IOException;
import java.net.URL;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

import java.awt.*;
import javax.swing.*;
import javax.swing.border.TitledBorder;


@SpringBootApplication
public class assignment2 extends JFrame {

    /**
     *
     */
    private static final long serialVersionUID = 1L;

    public assignment2() {

        initUI();
    }

    private void initUI() {
        /* Duck Instances*/

        Duck mellard = new MellardDuck();
        Duck rubber = new RubberDuck();
        Duck redhead = new RedheadDuck();

        /* Image ICONS */

        ImageIcon icon1 = new ImageIcon();
        ImageIcon icon2 = new ImageIcon();

        ImageIcon icon3 = new ImageIcon();
        ImageIcon icon4 = new ImageIcon();

        /* Buttons for Duck Behaviors */

        JButton behav0 = new JButton("Display Default");
        JButton behav1 = new JButton();
        JButton behav2 = new JButton();
        JButton behav3 = new JButton();
        JButton behav4 = new JButton();
        JButton behav5 = new JButton();
        JButton behav6 = new JButton();
        JButton behav7 = new JButton();

        /* Displaying Icons of ducks mentioned in duck.txt file */

		try {
            File myObj = new File("src/main/java/com/example/demo/duck.txt");
            Scanner myReader = new Scanner(myObj);
            while (myReader.hasNextLine()) {
              String data = myReader.nextLine();
              if(data.equalsIgnoreCase("mallard")==true)
               icon3 = new ImageIcon("src/main/java/com/example/demo/mallard_duck.png");
              if(data.equalsIgnoreCase("rubber")==true)
               icon1 = new ImageIcon("src/main/java/com/example/demo/rubber_duck.png");
              if(data.equalsIgnoreCase("redhead")==true)
               icon2 = new ImageIcon("src/main/java/com/example/demo/redhead_duck.png");
               if(data.equalsIgnoreCase("grid")==true)
               icon4 = new ImageIcon("src/main/java/com/example/demo/grid.png");
                

            }
            myReader.close();
          } catch (FileNotFoundException e) {
            System.out.println("An error occurred.");
            e.printStackTrace();
          }

          PaletteComponent mellardDuckIcon = new PaletteDuckIcon(icon3);
          PaletteComponent rubberDuckIcon  = new PaletteDuckIcon(icon1);
          PaletteComponent redheadDuckIcon = new PaletteDuckIcon(icon2);
          PaletteComponent gridIcon = new PaletteGridIcon(icon4);
  
          /* Reading behaviors mentioned in behavior.txt */

          try {
            File myObj1 = new File("src/main/java/com/example/demo/behavior.txt");
            Scanner myReader1 = new Scanner(myObj1);
            while (myReader1.hasNextLine()) {
              String data1 = myReader1.nextLine();
              if(data1.equalsIgnoreCase("flyWithWings")==true)
              {
               behav1 = new JButton("flyWithWings");
         
              }
            
               if(data1.equalsIgnoreCase("flyNoWay")==true)
               {
               behav2 = new JButton("flyNoWay");
             
               }
            
               if(data1.equalsIgnoreCase("flyRocketPowered")==true)
               {
               behav3 = new JButton("flyRocketPowered");
    
               }
        
               if(data1.equalsIgnoreCase("Quack")==true)
               {
               behav4 = new JButton("Quack");
        
               }
        
               if(data1.equalsIgnoreCase("Mute")==true)
               {
               behav5 = new JButton("Mute");
              
               }
               
               if(data1.equalsIgnoreCase("Squeak")==true)
               {
               behav6 = new JButton("Squeak");
              
               }
            
               if(data1.equalsIgnoreCase("QuackwithRythm")==true)
               {
               behav7 = new JButton("QuackwithRythm");
            
               }
              
                

            }
            myReader1.close();
          } catch (FileNotFoundException e) {
            System.out.println("An error occurred.");
            e.printStackTrace();
          }

        // /* Labels for images icons */

        var label1 = new JLabel(icon1, JLabel.CENTER);
        var label2 = new JLabel(icon2, JLabel.CENTER);
        var label3 = new JLabel(icon3, JLabel.CENTER);
        var label4 = new JLabel(icon4, JLabel.CENTER);  

        // /* Adding Mouse Listener for Drag and Drop Functionality */

         var listener = new DragMouseAdapter();
        label1.addMouseListener(listener);
        label2.addMouseListener(listener);
        label3.addMouseListener(listener);
        label4.addMouseListener(listener);
        var frame = new JFrame();

        
        /* Buttons for creating 2x2 Grid */

        var b1 = new JButton();
        var b2 = new JButton();
        var b3 = new JButton();
        var b4 = new JButton();
        b1.setFocusable(false);
        b2.setFocusable(false);
        b3.setFocusable(false);
        b4.setFocusable(false);
        behav0.setFocusable(false);
        behav1.setFocusable(false);
        behav2.setFocusable(false);
        behav3.setFocusable(false);
        behav4.setFocusable(false);
        behav5.setFocusable(false);
        behav6.setFocusable(false);
        behav7.setFocusable(false);

        /* Buttons for decorating */

        var redButton   = new JButton();
        redButton.setText("Red");
        redButton.setBackground(Color.red);
        var greenButton = new JButton();
        greenButton.setText("Green");
        redButton.setBackground(Color.green);
        var blueButton  = new JButton();
        blueButton.setText("Blue");
        blueButton.setBackground(Color.blue);


        /* Display Default properties of duck when Display Default button is clicked */

        behav0.addActionListener(new ActionListener(){
            int count=0;
            @Override
            public void actionPerformed(ActionEvent e) {
                // TODO Auto-generated method stub
                b1.addActionListener(new ActionListener() {
                    
                    public void actionPerformed(ActionEvent arg0) {
                        String msg;
                        if(count==0)
                        {
                        msg=mellard.display() +". " + mellard.swim() + ". "+ mellard.PerformFly()+". " + mellard.PerformQuack();
                       // if(count==0)
                        JOptionPane.showMessageDialog (frame.getComponent(0), msg);
                        }
                        count=1;
        
                    }
                });
                b2.addActionListener(new ActionListener() {
                    
                   
                    public void actionPerformed(ActionEvent arg0) {
                        String msg;
                        if(count==0)
                        {
                        msg=redhead.display() +". " + redhead.swim() + ". "+ redhead.PerformFly()+". " + redhead.PerformQuack();
                       // if(count==0)
                        JOptionPane.showMessageDialog (frame.getComponent(0), msg);
                        }
                        count=1;
        
                    }
                });
                b3.addActionListener(new ActionListener() {
                    
                    public void actionPerformed(ActionEvent arg0) {
                        String msg;
                        if(count==0)
                        {
                        msg=rubber.display() +". " + rubber.swim() + ". "+ rubber.PerformFly()+". " + rubber.PerformQuack();
                        //if(count==0)
                        JOptionPane.showMessageDialog (frame.getComponent(0), msg);
                        }
                        count=1;
        
                    }
                });
            count=0;
            }
            
        });
        
        /* Add FlywithWings Behavior in ducks dynamically */

        behav1.addActionListener(new ActionListener() {
            int count1=0;
            @Override
            public void actionPerformed(ActionEvent e) {
                b1.addActionListener(new ActionListener() {
                    
                    public void actionPerformed(ActionEvent arg0) {
                        String msg;
                        if (count1==0)
                        {
                        mellard.setFlyBehavior(new FlywithWings());
                        msg=mellard.display() +". " + mellard.swim() + ". "+ mellard.PerformFly()+". " + mellard.PerformQuack();
                        
                        JOptionPane.showMessageDialog (frame.getComponent(0), msg);
                        }
                        count1=1;
        
                    }
                });
                b2.addActionListener(new ActionListener() {

                    public void actionPerformed(ActionEvent arg0) {
                        String msg;
                        if(count1==0)
                        {
                        redhead.setFlyBehavior(new FlywithWings());
                        msg=redhead.display() +". " + redhead.swim() + ". "+ redhead.PerformFly()+". " + redhead.PerformQuack();
                        
                        JOptionPane.showMessageDialog (frame.getComponent(0), msg);
                        }
                        count1=1;
        
                    }
                });

                b3.addActionListener(new ActionListener() {

                    public void actionPerformed(ActionEvent arg0) {
                        
                        String msg;
                        if(count1==0)
                        {
                        rubber.setFlyBehavior(new FlywithWings());
                        msg=rubber.display() +". " + rubber.swim() + ". "+ rubber.PerformFly()+". " + rubber.PerformQuack();
                        
                        JOptionPane.showMessageDialog (frame.getComponent(0), msg);
                        }
                        count1=1;
        
                    }
                });
                count1=0;
            }

        });

        /* Add FlyNoWay Behavior in ducks dynamically */

        behav2.addActionListener(new ActionListener() {
            int count2=0;
            @Override
            public void actionPerformed(ActionEvent e) {
                b1.addActionListener(new ActionListener() {

                    public void actionPerformed(ActionEvent arg0) {
                        
                        String msg;
                        if(count2==0)
                        {
                        mellard.setFlyBehavior(new FlyNoWay());
                        msg=mellard.display() +". " + mellard.swim() + ". "+ mellard.PerformFly()+". " + mellard.PerformQuack();
                        
                        JOptionPane.showMessageDialog (frame.getComponent(0), msg);
                        }
                        count2=1;
        
                    }
                });
                b2.addActionListener(new ActionListener() {

                    public void actionPerformed(ActionEvent arg0) {
                 
                        String msg;
                        if(count2==0)
                        {
                        redhead.setFlyBehavior(new FlyNoWay());
                        msg=redhead.display() +". " + redhead.swim() + ". "+ redhead.PerformFly()+". " + redhead.PerformQuack();
                        
                        JOptionPane.showMessageDialog (frame.getComponent(0), msg);
                        }
                        count2=1;
        
                    }
                });

                b3.addActionListener(new ActionListener() {

                    public void actionPerformed(ActionEvent arg0) {
                      
                        String msg;
                        if(count2==0)
                        {
                        rubber.setFlyBehavior(new FlyNoWay());
                        msg=rubber.display() +". " + rubber.swim() + ". "+ rubber.PerformFly()+". " + rubber.PerformQuack();
                        
                        JOptionPane.showMessageDialog (frame.getComponent(0), msg);
                        }
                        count2=1;
        
                    }
                });
                count2=0;
            }

        });

        /* Add FlyWithRocketPowered Behavior in ducks dynamically */

        behav3.addActionListener(new ActionListener() {
            int count3=0;
            @Override
            public void actionPerformed(ActionEvent e) {
                b1.addActionListener(new ActionListener() {
                    
                    public void actionPerformed(ActionEvent arg0) {
                        
                        String msg;
                        if(count3==0)
                        {
                        mellard.setFlyBehavior(new FlyRocketPowered());
                        msg=mellard.display() +". " + mellard.swim() + ". "+ mellard.PerformFly()+". " + mellard.PerformQuack();
                        
                        JOptionPane.showMessageDialog (frame.getComponent(0), msg);
                        }
                        
                        count3=1;
                    }
                });
                b2.addActionListener(new ActionListener() {

                    public void actionPerformed(ActionEvent arg0) {
                        String msg;
                        if(count3==0)
                        {
                        redhead.setFlyBehavior(new FlyRocketPowered());
                        msg=redhead.display() +". " + redhead.swim() + ". "+ redhead.PerformFly()+". " + redhead.PerformQuack();
                        
                        JOptionPane.showMessageDialog (frame.getComponent(0), msg);
                        }
                        count3=1;
                    }
                });

                b3.addActionListener(new ActionListener() {

                    public void actionPerformed(ActionEvent arg0) {
                        String msg;
                        if(count3==0)
                        {
                        rubber.setFlyBehavior(new FlyRocketPowered());
                        msg=rubber.display() +". " + rubber.swim() + ". "+ rubber.PerformFly()+". " + rubber.PerformQuack();
                        
                        JOptionPane.showMessageDialog (frame.getComponent(0), msg);
                        }
                        count3=1;
                    }
                });
                
                count3=0;
            }
            

        });
        /* Add Quack Behavior in ducks dynamically */
        behav4.addActionListener(new ActionListener() {
            int count4=0;
            @Override
            public void actionPerformed(ActionEvent e) {
                b1.addActionListener(new ActionListener() {

                    public void actionPerformed(ActionEvent arg0) {
                        String msg;
                        mellard.setQuackBehavior(new Quack());
                        if(count4==0)
                        {
                        msg=mellard.display() +". " + mellard.swim() + ". "+ mellard.PerformFly()+". " + mellard.PerformQuack();
                        
                        JOptionPane.showMessageDialog (frame.getComponent(0), msg);
                        }
                        count4=1;
        
                    }
                });
                b2.addActionListener(new ActionListener() {

                    public void actionPerformed(ActionEvent arg0) {
                        String msg;
                        if(count4==0)
                        {
                        redhead.setQuackBehavior(new Quack());
                        msg=redhead.display() +". " + redhead.swim() + ". "+ redhead.PerformFly()+". " + redhead.PerformQuack();
                        
                        JOptionPane.showMessageDialog (frame.getComponent(0), msg);
                        }
                        count4=1;
        
                    }
                });

                b3.addActionListener(new ActionListener() {

                    public void actionPerformed(ActionEvent arg0) {
                        String msg;
                        if(count4==0)
                        {
                        rubber.setQuackBehavior(new Quack());
                        msg=rubber.display() +". " + rubber.swim() + ". "+ rubber.PerformFly()+". " + rubber.PerformQuack();
                        
                        JOptionPane.showMessageDialog (frame.getComponent(0), msg);
                        }
                        count4=1;
        
                    }
                });
                count4=0;
            }

        });

        /* Add Mute Behavior in ducks dynamically */

        behav5.addActionListener(new ActionListener() {
            int count5=0;
            @Override
            public void actionPerformed(ActionEvent e) {
                b1.addActionListener(new ActionListener() {

                    public void actionPerformed(ActionEvent arg0) {
                        String msg;
                        if(count5==0)
                        {
                        mellard.setQuackBehavior(new MuteQuack());
                        msg=mellard.display() +". " + mellard.swim() + ". "+ mellard.PerformFly()+". " + mellard.PerformQuack();
                        
                        JOptionPane.showMessageDialog (frame.getComponent(0), msg);
                        }
                        count5=1;
        
                    }
                });
                b2.addActionListener(new ActionListener() {

                    public void actionPerformed(ActionEvent arg0) {
                        String msg;
                        if(count5==0)
                        {
                        redhead.setQuackBehavior(new MuteQuack());
                        msg=redhead.display() +". " + redhead.swim() + ". "+ redhead.PerformFly()+". " + redhead.PerformQuack();
                        
                        JOptionPane.showMessageDialog (frame.getComponent(0), msg);
                        }
                        count5=1;
        
                    }
                });

                b3.addActionListener(new ActionListener() {

                    public void actionPerformed(ActionEvent arg0) {
                        String msg;
                        if(count5==0)
                        {
                        rubber.setQuackBehavior(new MuteQuack());
                        msg=rubber.display() +". " + rubber.swim() + ". "+ rubber.PerformFly()+". " + rubber.PerformQuack();
                        
                        JOptionPane.showMessageDialog (frame.getComponent(0), msg);
                        }
                        count5=1;
        
                    }
                });
                count5=0;
            }

        });
        /* Add Squeak Behavior in ducks dynamically */
        behav6.addActionListener(new ActionListener() {
            int count6=0;
            @Override
            public void actionPerformed(ActionEvent e) {
                b1.addActionListener(new ActionListener() {

                    public void actionPerformed(ActionEvent arg0) {
                        String msg;
                        if(count6==0)
                        {
                        mellard.setQuackBehavior(new Squeak());
                        msg=mellard.display() +". " + mellard.swim() + ". "+ mellard.PerformFly()+". " + mellard.PerformQuack();
                        
                        JOptionPane.showMessageDialog (frame.getComponent(0), msg);
                        }
                        count6=1;
        
                    }
                });
                b2.addActionListener(new ActionListener() {

                    public void actionPerformed(ActionEvent arg0) {
                        String msg;
                        if(count6==0)
                        {
                        redhead.setQuackBehavior(new Squeak());
                        msg=redhead.display() +". " + redhead.swim() + ". "+ redhead.PerformFly()+". " + redhead.PerformQuack();
                        JOptionPane.showMessageDialog (frame.getComponent(0), msg);
                        }
                        count6=1;
        
                    }
                });

                b3.addActionListener(new ActionListener() {

                    public void actionPerformed(ActionEvent arg0) {
                        String msg;
                        if(count6==0)
                        {
                        rubber.setQuackBehavior(new Squeak());
                        msg=rubber.display() +". " + rubber.swim() + ". "+ rubber.PerformFly()+". " + rubber.PerformQuack();
                        
                        JOptionPane.showMessageDialog (frame.getComponent(0), msg);
                        }
                        count6=1;
        
                    }
                });
                count6=0;
            }

        });

        /* Add QuackWithRythm Behavior in ducks dynamically */

        behav7.addActionListener(new ActionListener() {
            int count7=0;
            @Override
            public void actionPerformed(ActionEvent e) {
                b1.addActionListener(new ActionListener() {

                    public void actionPerformed(ActionEvent arg0) {
                        String msg;
                        if(count7==0)
                        {
                        mellard.setQuackBehavior(new QuackwithRythm());
                        msg=mellard.display() +". " + mellard.swim() + ". "+ mellard.PerformFly()+". " + mellard.PerformQuack();
                        JOptionPane.showMessageDialog (frame.getComponent(0), msg);
                        }
                        count7=1;
        
                    }
                });
                b2.addActionListener(new ActionListener() {

                    public void actionPerformed(ActionEvent arg0) {
                        String msg;
                        if(count7==0)
                        {
                        redhead.setQuackBehavior(new QuackwithRythm());
                        msg=redhead.display() +". " + redhead.swim() + ". "+ redhead.PerformFly()+". " + redhead.PerformQuack();
                        JOptionPane.showMessageDialog (frame.getComponent(0), msg);
                        }
                        count7=1;
        
                    }
                });

                b3.addActionListener(new ActionListener() {

                    public void actionPerformed(ActionEvent arg0) {
                        String msg;
                        if(count7==0)
                        {
                        rubber.setQuackBehavior(new QuackwithRythm());
                        msg=rubber.display() +". " + rubber.swim() + ". "+ rubber.PerformFly()+". " + rubber.PerformQuack();
                        JOptionPane.showMessageDialog (frame.getComponent(0), msg);
                        }
                        count7=1;
        
                    }
                });
            count7=0;
            }

        });        
        /* Drag and Drop Transfer Handler */
        label1.setTransferHandler(new TransferHandler("icon"));
        label2.setTransferHandler(new TransferHandler("icon"));
        label3.setTransferHandler(new TransferHandler("icon"));
        label4.setTransferHandler(new TransferHandler("icon"));
        // b1.setTransferHandler(new TransferHandler("icon"));
        // b2.setTransferHandler(new TransferHandler("icon"));
        // b3.setTransferHandler(new TransferHandler("icon"));
        // b4.setTransferHandler(new TransferHandler("icon"));

        /* creating GUI layout*/

        JLabel canvasLabel = new JLabel();
		JPanel canvasPanel = new JPanel();
		canvasPanel.add(canvasLabel);
        canvasPanel.setBackground(Color.white);
        canvasPanel.setPreferredSize(new Dimension (400, 700));

        // var listener = new DragMouseAdapter();
        // canvasPanel.addMouseListener(listener);
        canvasPanel.setTransferHandler(new TransferHandler("icon"));
        // canvasLabel.addMouseListener(listener);
        canvasLabel.setTransferHandler(new TransferHandler("icon"));



        createPannedLayout(label1, label2, label3,label4, b1,b2,b3,b4,behav1,behav2,behav3,behav4,behav5,behav6,behav7,behav0,
        redButton, greenButton, blueButton, canvasLabel, canvasPanel);

        setTitle("Assignment 4");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
    }

    private class DragMouseAdapter extends MouseAdapter {

        public void mousePressed(MouseEvent e) {

            var c = (JComponent) e.getSource();
            var handler = c.getTransferHandler();
            handler.exportAsDrag(c, e, TransferHandler.COPY);
        }
    }

    private void createPannedLayout(JComponent... arg) 
    {
        JLabel canvasLabel = new JLabel();
		JPanel canvasPanel = new JPanel();
		canvasPanel.add(canvasLabel);
        canvasPanel.setBackground(Color.white);
        canvasPanel.setPreferredSize(new Dimension (400, 700));
        
        JLabel paletteLabel = new JLabel();
		JPanel palettePanel = new JPanel();
		palettePanel.add(paletteLabel);
        palettePanel.setBackground(Color.white);
        // palettePanel.setSize(400, 500);
        palettePanel.setLayout(new BoxLayout(palettePanel, BoxLayout.Y_AXIS));

        JLabel behaviorsLabel = new JLabel();
		JPanel behaviorsPanel = new JPanel();
		behaviorsPanel.add(behaviorsLabel);
        behaviorsPanel.setBackground(Color.white);
        behaviorsPanel.setPreferredSize(new Dimension (100, 700));
        behaviorsPanel.setLayout(new BoxLayout(behaviorsPanel, BoxLayout.Y_AXIS));

        JPanel testCanvasPanel = createCanvasJPanel();
        JPanel testPalettePanel = createPalettePanel(arg[0], arg[1], arg[2]);


        canvasPanel.add(arg[4]);
        canvasPanel.add(arg[5]);
        canvasPanel.add(arg[6]);
        canvasPanel.add(arg[7]);

        palettePanel.add(arg[0]);
        palettePanel.add(arg[1]);
        palettePanel.add(arg[2]);
        palettePanel.add(arg[3]);
        palettePanel.add(arg[16]);
        palettePanel.add(arg[17]);
        palettePanel.add(arg[18]);

        
        behaviorsPanel.add(arg[8]);
        behaviorsPanel.add(arg[9]);
        behaviorsPanel.add(arg[10]);
        behaviorsPanel.add(arg[11]);
        behaviorsPanel.add(arg[12]);
        behaviorsPanel.add(arg[13]);
        behaviorsPanel.add(arg[14]);
        behaviorsPanel.add(arg[15]);

        JSplitPane sp1 = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, palettePanel, canvasPanel);
        sp1.setOneTouchExpandable(true);

        JSplitPane sp2 = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, sp1, behaviorsPanel);
        sp2.setOneTouchExpandable(true);

        JSplitPane sp3 = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, sp2, testCanvasPanel);
        sp3.setOneTouchExpandable(true);

        JSplitPane sp4 = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, sp3, testPalettePanel);
        sp4.setOneTouchExpandable(true);



        var pane = getContentPane();

        pane.add(sp3);
    }


    private static JPanel createCanvasJPanel() {
        final JPanel p = new JPanel() {
            @Override
            public Dimension getPreferredSize() {
                return new Dimension(300, 300);
            }
        };
        p.setBorder(new TitledBorder("Drag Image onto this panel"));

        TransferHandler dnd = new TransferHandler() {
            @Override
            public boolean canImport(TransferSupport support) {
                if (!support.isDrop()) {
                    return false;
                }
                //only Strings
                if (!support.isDataFlavorSupported(DataFlavor.imageFlavor)) {
                    return false;
                }
                return true;
            }

            @Override
            public boolean importData(TransferSupport support) {
                if (!canImport(support)) {
                    return false;
                }

                Transferable tansferable = support.getTransferable();
                Icon ico;
                try {
                    ico = (Icon) tansferable.getTransferData(DataFlavor.imageFlavor);
                } catch (Exception e) {
                    e.printStackTrace();
                    return false;
                }
                p.add(new JLabel(ico));
                return true;
            }
        };

        p.setTransferHandler(dnd);

        return p;
    }


    private static JPanel createPalettePanel(JComponent l1, JComponent l2, JComponent l3) throws Exception {
        JPanel panel = new JPanel();
        panel.setBorder(new TitledBorder("Drag Image from here to Panel above"));

        JLabel label1 = (JLabel) l1;
        JLabel label2 = (JLabel) l2;
        JLabel label3 = (JLabel) l3;

        MyDragGestureListener dlistener = new MyDragGestureListener();
        DragSource ds1 = new DragSource();
        ds1.createDefaultDragGestureRecognizer(label1, DnDConstants.ACTION_COPY, dlistener);

        DragSource ds2 = new DragSource();
        ds2.createDefaultDragGestureRecognizer(label2, DnDConstants.ACTION_COPY, dlistener);

        DragSource ds3 = new DragSource();
        ds3.createDefaultDragGestureRecognizer(label3, DnDConstants.ACTION_COPY, dlistener);

        panel.add(label1);
        panel.add(label2);
        panel.add(label3);
        return panel;
    }


    class MyDropTargetListener extends DropTargetAdapter {

        private DropTarget dropTarget;
        private JPanel p;
    
        public MyDropTargetListener(JPanel panel) {
            p = panel;
            dropTarget = new DropTarget(panel, DnDConstants.ACTION_COPY, this, true, null);
    
        }
    
        @Override
        public void drop(DropTargetDropEvent event) {
            try {
                DropTarget test = (DropTarget) event.getSource();
                Component ca = (Component) test.getComponent();
                Point dropPoint = ca.getMousePosition();
                Transferable tr = event.getTransferable();
    
                if (event.isDataFlavorSupported(DataFlavor.imageFlavor)) {
                    Icon ico = (Icon) tr.getTransferData(DataFlavor.imageFlavor);
    
                    if (ico != null) {
    
                        p.add(new JLabel(ico));
                        p.revalidate();
                        p.repaint();
                        event.dropComplete(true);
                    }
                } else {
                    event.rejectDrop();
                }
            } catch (Exception e) {
                e.printStackTrace();
                event.rejectDrop();
            }
        }
    }
    
    class MyDragGestureListener implements DragGestureListener {
    
        @Override
        public void dragGestureRecognized(DragGestureEvent event) {
            JLabel label = (JLabel) event.getComponent();
            final Icon ico = label.getIcon();
    
    
            Transferable transferable = new Transferable() {
                @Override
                public DataFlavor[] getTransferDataFlavors() {
                    return new DataFlavor[]{DataFlavor.imageFlavor};
                }
    
                @Override
                public boolean isDataFlavorSupported(DataFlavor flavor) {
                    if (!isDataFlavorSupported(flavor)) {
                        return false;
                    }
                    return true;
                }
    
                @Override
                public Object getTransferData(DataFlavor flavor) throws UnsupportedFlavorException, IOException {
                    return ico;
                }
            };
            event.startDrag(null, transferable);
        }
    }

    
    public static void main(String[] args) {

        var ctx = new SpringApplicationBuilder(assignment2.class)
                .headless(false).run(args);

        EventQueue.invokeLater(() -> {

            var ex = ctx.getBean(assignment2.class);
			ex.setVisible(true);
        });
    }


    
}